# Ansible Collection - sunbird_rc.iac

Documentation for the collection.


ansible-galaxy collection install git+https://github.com/ddevadat/iac-ansible-collection-roles.git#/sunbird_rc/iac,main
ansible-playbook sunbird_rc.iac.sbrc_deploy -i /iac-run-dir/output/inventory